"""
Example Plugin: Voice Controller (Termux Compatible)
Uses Termux-API for voice input and output

Prerequisites:
1. Install Termux-API app from F-Droid
2. Run: pkg install termux-api
3. Grant microphone and speech permissions

This demonstrates self-modification - the assistant can add this
plugin when you say: "Add voice feature to yourself"
"""

import subprocess
import os

class VoiceControllerPlugin:
    """Voice input/output using Termux-API"""
    is_plugin = True
    
    def __init__(self, assistant):
        self.assistant = assistant
        self.name = "Voice Controller"
        self.version = "1.0.0"
        self.termux_available = self._check_termux_api()
    
    def _check_termux_api(self):
        """Check if Termux-API is available"""
        try:
            result = subprocess.run(
                ["which", "termux-tts-speak"],
                capture_output=True,
                text=True
            )
            return result.returncode == 0
        except:
            return False
    
    def speak(self, text: str) -> bool:
        """Convert text to speech using Termux-API"""
        if not self.termux_available:
            print("⚠️  Termux-API not available. Install with: pkg install termux-api")
            return False
        
        try:
            subprocess.run(
                ["termux-tts-speak", text],
                check=True
            )
            return True
        except Exception as e:
            print(f"❌ Speech failed: {e}")
            return False
    
    def listen(self) -> str:
        """Listen to voice input using Termux-API"""
        if not self.termux_available:
            print("⚠️  Termux-API not available. Install with: pkg install termux-api")
            return ""
        
        try:
            result = subprocess.run(
                ["termux-speech-to-text"],
                capture_output=True,
                text=True,
                check=True
            )
            return result.stdout.strip()
        except Exception as e:
            print(f"❌ Voice recognition failed: {e}")
            return ""
    
    def execute(self, command: str = "speak", text: str = ""):
        """Execute voice command"""
        if command == "speak":
            return self.speak(text)
        elif command == "listen":
            return self.listen()
        elif command == "conversation":
            return self.voice_conversation()
        else:
            return f"Unknown command: {command}"
    
    def voice_conversation(self):
        """Start voice-based conversation"""
        print("🎤 Voice conversation mode activated")
        print("   Say 'exit' to stop")
        
        self.speak("Voice conversation mode activated. How can I help you?")
        
        while True:
            print("\n🎤 Listening...")
            user_input = self.listen()
            
            if not user_input:
                continue
            
            print(f"👤 You said: {user_input}")
            
            if "exit" in user_input.lower() or "stop" in user_input.lower():
                self.speak("Goodbye!")
                break
            
            # Process through the assistant
            response = self.assistant.conversation_handler.process_input(user_input)
            print(f"🤖 AI: {response}")
            self.speak(response)
    
    def help(self):
        """Show help for voice plugin"""
        return """
Voice Controller Plugin v1.0.0
Uses Termux-API for voice input/output

Commands:
- speak <text>: Convert text to speech
- listen: Listen to voice input
- conversation: Start voice conversation mode

Prerequisites:
1. Install Termux-API app from F-Droid
2. Run: pkg install termux-api
3. Grant microphone and speech permissions

Example:
  voice speak "Hello, I am your AI assistant"
  voice listen
  voice conversation
"""


# Example usage
if __name__ == "__main__":
    print("Testing Voice Controller Plugin...")
    voice = VoiceControllerPlugin(None)
    print(voice.help())
    
    if voice.termux_available:
        print("✅ Termux-API is available")
        voice.speak("Voice plugin test successful")
    else:
        print("⚠️  Termux-API not available")
