# Complete Termux Setup Guide

## 🚀 Quick Start (5 Minutes)

### Step 1: Install Termux
1. Download **Termux** from F-Droid (NOT Google Play Store)
2. Open Termux

### Step 2: Update and Install Python
```bash
# Update packages
pkg update && pkg upgrade -y

# Install Python and Git
pkg install python python-pip git -y

# Verify installation
python --version
pip --version
```

### Step 3: Clone/Download This Project
```bash
# Option 1: If you have the files already
cd ~
# Copy the files to Termux storage

# Option 2: From Git (if hosted)
# git clone <repository-url>
# cd <project-directory>

# Option 3: Manual copy
# Use Termux to access files in your storage
termux-setup-storage
# Then copy files from Downloads
```

### Step 4: Install Dependencies
```bash
# Install all requirements
pip install -r requirements.txt

# Verify installation
pip list
```

### Step 5: Get OpenRouter API Key (FREE)
1. Visit https://openrouter.ai/ on your phone browser
2. Sign up (free account)
3. Go to "Keys" section
4. Create new API key
5. Copy the key (keep it safe)

### Step 6: Run the Assistant
```bash
python jarvis_advanced.py
```

The assistant will ask for your API key on first run. Paste it and press Enter.

## ✅ Complete Setup Checklist

- [ ] Termux installed from F-Droid
- [ ] Packages updated (`pkg update && pkg upgrade`)
- [ ] Python 3 installed (`pkg install python`)
- [ ] Git installed (`pkg install git`)
- [ ] Project files copied to Termux
- [ ] Dependencies installed (`pip install -r requirements.txt`)
- [ ] OpenRouter API key obtained
- [ ] Assistant running successfully

## 🎯 Optional Enhancements

### Voice Features (Termux-API)

For voice input/output support:

```bash
# 1. Install Termux-API app from F-Droid
# 2. Install termux-api package
pkg install termux-api -y

# 3. Grant permissions when prompted
# (Microphone, Speech)

# 4. Test voice
termux-tts-speak "Hello from Termux"
```

Then tell your assistant:
```
You: Add voice feature to yourself
AI: [Automatically adds voice plugin]
```

### Storage Access

To access your phone's storage:

```bash
termux-setup-storage
# Grant permission when prompted

# Now you can access:
# ~/storage/downloads  - Downloads folder
# ~/storage/dcim       - Camera photos
# ~/storage/shared     - Internal storage
```

### Background Execution

To keep the assistant running in background:

```bash
# Install Termux:Boot (from F-Droid)
# Then create startup script
mkdir -p ~/.termux/boot
nano ~/.termux/boot/start-assistant.sh
```

Add this to the file:
```bash
#!/data/data/com.termux/files/usr/bin/bash
cd ~/ai-assistant
python jarvis_advanced.py &
```

Make it executable:
```bash
chmod +x ~/.termux/boot/start-assistant.sh
```

## 🔧 Troubleshooting

### Problem: "ModuleNotFoundError"
**Solution:**
```bash
pip install -r requirements.txt
# Or install missing package
pip install <package-name>
```

### Problem: "Permission denied"
**Solution:**
```bash
chmod +x jarvis_advanced.py
termux-setup-storage  # Grant storage access
```

### Problem: "pip: command not found"
**Solution:**
```bash
pkg install python-pip
```

### Problem: "API key not working"
**Solution:**
1. Verify key at https://openrouter.ai/keys
2. Check if key has balance/credits
3. Try a different free model

### Problem: "Slow responses"
**Solution:**
- Check internet connection
- The AI will auto-switch to faster model
- Try different time (server load)

### Problem: "Voice not working"
**Solution:**
1. Install Termux-API app from F-Droid (NOT Play Store)
2. Run: `pkg install termux-api`
3. Grant all permissions
4. Test: `termux-tts-speak "test"`

## 📱 Termux Tips

### Keyboard Shortcuts
- `Ctrl + C` - Stop running program
- `Ctrl + D` - Exit/logout
- `Ctrl + L` - Clear screen
- `Volume Up + Q` - Show extra keys

### Essential Commands
```bash
# Update packages
pkg update && pkg upgrade

# List installed packages
pkg list-installed

# Search for package
pkg search <name>

# Install package
pkg install <name>

# Uninstall package
pkg uninstall <name>

# Clean cache
pkg clean
```

### Storage Locations
- Termux home: `~` or `$HOME`
- Assistant data: `~/.ai_assistant/`
- Projects: `~/.ai_assistant/projects/`
- Logs: `~/.ai_assistant/logs/`
- Plugins: `~/.ai_assistant/plugins/`

## 🎓 Usage Examples

### Example 1: Create a Project
```
You: Create a calculator project for me
AI: [Creates project automatically]
    ✅ Project 'calculator' successfully created!
    Location: ~/.ai_assistant/projects/calculator
```

### Example 2: Analyze Code
```
You: Check my project for errors
AI: [Analyzes code]
    📊 Project Analysis: calculator
    Files: 3
    Errors: 0
    ✅ No errors found!
```

### Example 3: Self-Modification
```
You: Add a feature to calculate factorial
AI: [Modifies itself]
    🔧 Testing new feature...
    ✅ Feature added successfully!
    You can now ask me to calculate factorials.
```

### Example 4: GitHub Learning
```
You: Learn from GitHub trending Python projects
AI: [Searches GitHub]
    📚 Found 10 trending projects
    🧠 Learning patterns...
    ✅ Improved code generation capabilities!
```

## 🔒 Security Tips

1. **Never share your API key** with anyone
2. **Use free models** to avoid unexpected charges
3. **Regular backups**: Copy `~/.ai_assistant/` folder
4. **Update regularly**: `pkg update && pkg upgrade`
5. **Review plugins** before adding them

## 📊 Resource Management

### Check Storage
```bash
df -h ~  # Check available space
du -sh ~/.ai_assistant  # Check assistant size
```

### Monitor Memory
```bash
# The assistant auto-manages memory
# But you can check manually:
free -h
```

### Clean Up
```bash
# Remove old logs
rm -rf ~/.ai_assistant/logs/*

# Remove old projects
rm -rf ~/.ai_assistant/projects/old_*

# Clear package cache
pkg clean
```

## 🌟 Advanced Features

### Custom Plugins

Create your own plugin:

```bash
nano ~/.ai_assistant/plugins/my_plugin.py
```

```python
class MyPlugin:
    is_plugin = True
    
    def __init__(self, assistant):
        self.assistant = assistant
    
    def execute(self, *args, **kwargs):
        return "My custom plugin!"
```

Or just tell the assistant:
```
You: Create a plugin that <describe what you want>
AI: [Creates and tests plugin automatically]
```

### Scheduled Tasks

Use Termux cron for scheduled execution:

```bash
pkg install cronie termux-services
sv-enable crond

# Edit crontab
crontab -e

# Add scheduled task (example: daily at 9 AM)
0 9 * * * cd ~/ai-assistant && python -c "from jarvis_advanced import *; AdvancedAIAssistant().run()"
```

## 🆘 Getting Help

If you encounter issues:

1. Check this guide thoroughly
2. Read error messages carefully
3. Try the troubleshooting section
4. Check logs: `cat ~/.ai_assistant/logs/*.log`
5. Test internet connection
6. Restart Termux
7. Reinstall dependencies

## 📚 Additional Resources

- Termux Wiki: https://wiki.termux.com
- OpenRouter Docs: https://openrouter.ai/docs
- Python 3 Docs: https://docs.python.org/3/

## 🎉 You're All Set!

Your Advanced AI Assistant is now ready to use on Termux!

Start chatting:
```bash
python jarvis_advanced.py
```

Enjoy your powerful, self-improving AI assistant! 🚀
