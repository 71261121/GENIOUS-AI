"""
Example Plugin: Calculator
Demonstrates how to create a plugin for the Advanced AI Assistant

To use this plugin:
1. Copy this file to ~/.ai_assistant/plugins/calculator.py
2. The assistant will automatically load it on next start
3. Or tell the assistant: "Add calculator plugin" and it will create it
"""

class CalculatorPlugin:
    """Simple calculator plugin"""
    is_plugin = True
    
    def __init__(self, assistant):
        self.assistant = assistant
        self.name = "Calculator"
        self.version = "1.0.0"
    
    def execute(self, operation: str = "add", a: float = 0, b: float = 0):
        """Execute calculator operation"""
        operations = {
            "add": lambda x, y: x + y,
            "subtract": lambda x, y: x - y,
            "multiply": lambda x, y: x * y,
            "divide": lambda x, y: x / y if y != 0 else "Error: Division by zero",
            "power": lambda x, y: x ** y,
            "modulo": lambda x, y: x % y if y != 0 else "Error: Division by zero"
        }
        
        if operation in operations:
            result = operations[operation](a, b)
            return f"{a} {operation} {b} = {result}"
        else:
            return f"Unknown operation: {operation}"
    
    def help(self):
        """Show help for calculator plugin"""
        return """
Calculator Plugin v1.0.0
Available operations:
- add: a + b
- subtract: a - b
- multiply: a * b
- divide: a / b
- power: a ^ b
- modulo: a % b

Usage example:
  calculator add 5 3
  calculator divide 10 2
"""


# Example usage (when loaded as plugin):
if __name__ == "__main__":
    # Test the plugin
    calc = CalculatorPlugin(None)
    print(calc.execute("add", 5, 3))
    print(calc.execute("multiply", 7, 8))
    print(calc.execute("divide", 20, 4))
    print(calc.help())
