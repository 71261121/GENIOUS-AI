#!/usr/bin/env python3
"""
Advanced Automation Engine - Real Execution, No Suggestions
100% Termux Compatible | Multiple Retry Strategies | Zero Error Display

This module handles all actual automation tasks:
- Live code modification
- Feature installation
- Project creation and management
- Error detection and fixing
- Command execution
"""

import os
import sys
import subprocess
import json
import time
import re
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
import ast
import shutil

class AutomationEngine:
    """Core automation engine that actually executes tasks"""
    
    def __init__(self, assistant):
        self.assistant = assistant
        self.max_retries = 10
        self.last_error = None
        
    def add_feature_to_self(self, feature_description: str) -> Tuple[bool, str]:
        """
        Actually add a feature to the assistant - NO SUGGESTIONS
        Returns (success, message)
        """
        print(f"\n🔧 Adding feature: {feature_description}")
        print("⏳ Working in background...")
        
        # Determine what kind of feature
        if "voice" in feature_description.lower():
            return self._add_voice_feature()
        elif "youtube" in feature_description.lower() or "browser" in feature_description.lower():
            return self._add_browser_automation()
        elif "file" in feature_description.lower() or "manager" in feature_description.lower():
            return self._add_file_manager()
        elif "calculator" in feature_description.lower():
            return self._add_calculator_feature()
        else:
            # Use AI to generate custom feature
            return self._add_custom_feature(feature_description)
    
    def _add_voice_feature(self) -> Tuple[bool, str]:
        """Add voice output using Termux-API"""
        plugin_code = '''#!/usr/bin/env python3
"""Voice Output Plugin - Termux Compatible"""

import subprocess
import os

class VoiceOutputPlugin:
    is_plugin = True
    
    def __init__(self, assistant):
        self.assistant = assistant
        self.termux_api_available = self._check_termux_api()
    
    def _check_termux_api(self):
        """Check if termux-tts-speak is available"""
        try:
            result = subprocess.run(
                ["which", "termux-tts-speak"],
                capture_output=True,
                timeout=5
            )
            return result.returncode == 0
        except:
            return False
    
    def speak(self, text: str) -> bool:
        """Speak text using Termux TTS"""
        if not self.termux_api_available:
            # Try to install termux-api
            try:
                subprocess.run(["pkg", "install", "-y", "termux-api"], 
                             timeout=60, check=True)
                self.termux_api_available = True
            except:
                return False
        
        try:
            subprocess.run(
                ["termux-tts-speak", text],
                timeout=30,
                check=True
            )
            return True
        except:
            return False
    
    def execute(self, command="speak", text=""):
        """Execute voice command"""
        if command == "speak":
            return self.speak(text)
        return False
'''
        
        # Save plugin
        try:
            plugin_file = self.assistant.plugins_dir / "voice_output.py"
            plugin_file.write_text(plugin_code)
            
            # Load the plugin
            self.assistant.plugin_manager._load_plugins()
            
            # Test it
            if "voice_output" in self.assistant.plugin_manager.plugins:
                return (True, "✅ Voice output feature successfully added! Ab aap 'speak karo <text>' bol sakte hain.")
            else:
                return (False, "Plugin file created but failed to load")
        
        except Exception as e:
            return (False, f"Failed to add voice feature: {str(e)}")
    
    def _add_browser_automation(self) -> Tuple[bool, str]:
        """Add browser/YouTube automation"""
        plugin_code = '''#!/usr/bin/env python3
"""Browser Automation Plugin - Termux Compatible"""

import subprocess

class BrowserAutomationPlugin:
    is_plugin = True
    
    def __init__(self, assistant):
        self.assistant = assistant
    
    def open_url(self, url: str) -> bool:
        """Open URL in browser"""
        try:
            subprocess.run(
                ["am", "start", "-a", "android.intent.action.VIEW", "-d", url],
                timeout=10,
                check=True
            )
            return True
        except:
            return False
    
    def open_youtube(self, query: str = "") -> bool:
        """Open YouTube"""
        if query:
            url = f"https://www.youtube.com/results?search_query={query.replace(' ', '+')}"
        else:
            url = "https://www.youtube.com"
        return self.open_url(url)
    
    def execute(self, command="open", url=""):
        """Execute browser command"""
        if command == "youtube":
            return self.open_youtube(url)
        elif command == "open":
            return self.open_url(url)
        return False
'''
        
        try:
            plugin_file = self.assistant.plugins_dir / "browser_automation.py"
            plugin_file.write_text(plugin_code)
            self.assistant.plugin_manager._load_plugins()
            
            if "browser_automation" in self.assistant.plugin_manager.plugins:
                return (True, "✅ Browser automation feature added! Commands: 'open youtube', 'open <url>'")
            return (False, "Plugin creation failed")
        except Exception as e:
            return (False, f"Error: {str(e)}")
    
    def _add_file_manager(self) -> Tuple[bool, str]:
        """Add file manager feature"""
        plugin_code = '''#!/usr/bin/env python3
"""File Manager Plugin"""

import os
import shutil
from pathlib import Path

class FileManagerPlugin:
    is_plugin = True
    
    def __init__(self, assistant):
        self.assistant = assistant
    
    def list_files(self, path="."):
        """List all files in directory"""
        try:
            path_obj = Path(path).expanduser()
            files = []
            for item in path_obj.iterdir():
                files.append({
                    "name": item.name,
                    "type": "dir" if item.is_dir() else "file",
                    "size": item.stat().st_size if item.is_file() else 0
                })
            return files
        except Exception as e:
            return []
    
    def create_file(self, filename, content=""):
        """Create a new file"""
        try:
            Path(filename).write_text(content)
            return True
        except:
            return False
    
    def delete_file(self, filename):
        """Delete a file"""
        try:
            Path(filename).unlink()
            return True
        except:
            return False
    
    def execute(self, command="list", **kwargs):
        """Execute file command"""
        if command == "list":
            return self.list_files(kwargs.get("path", "."))
        elif command == "create":
            return self.create_file(kwargs.get("filename"), kwargs.get("content", ""))
        elif command == "delete":
            return self.delete_file(kwargs.get("filename"))
        return False
'''
        
        try:
            plugin_file = self.assistant.plugins_dir / "file_manager.py"
            plugin_file.write_text(plugin_code)
            self.assistant.plugin_manager._load_plugins()
            
            return (True, "✅ File manager feature added! Commands: 'list files', 'create file', 'delete file'")
        except Exception as e:
            return (False, f"Error: {str(e)}")
    
    def _add_calculator_feature(self) -> Tuple[bool, str]:
        """Add calculator"""
        plugin_code = '''#!/usr/bin/env python3
"""Calculator Plugin"""

import math

class CalculatorPlugin:
    is_plugin = True
    
    def __init__(self, assistant):
        self.assistant = assistant
    
    def calculate(self, expression: str):
        """Safely evaluate mathematical expression"""
        try:
            # Remove dangerous functions
            safe_dict = {
                "abs": abs, "round": round, "min": min, "max": max,
                "sum": sum, "pow": pow, "sqrt": math.sqrt,
                "sin": math.sin, "cos": math.cos, "tan": math.tan,
                "pi": math.pi, "e": math.e
            }
            result = eval(expression, {"__builtins__": {}}, safe_dict)
            return result
        except Exception as e:
            return f"Error: {str(e)}"
    
    def execute(self, expression=""):
        """Execute calculation"""
        return self.calculate(expression)
'''
        
        try:
            plugin_file = self.assistant.plugins_dir / "calculator.py"
            plugin_file.write_text(plugin_code)
            self.assistant.plugin_manager._load_plugins()
            
            return (True, "✅ Calculator feature added! Use: 'calculate 5 + 3'")
        except Exception as e:
            return (False, f"Error: {str(e)}")
    
    def _add_custom_feature(self, description: str) -> Tuple[bool, str]:
        """Generate and add custom feature using AI"""
        if not self.assistant.ai_engine:
            return (False, "AI engine not available for custom features")
        
        prompt = f"""Generate a Python plugin class for this feature: {description}

Requirements:
- Class must have 'is_plugin = True'
- Must have __init__(self, assistant) method
- Must have execute() method
- Must work on Termux (pure Python only)
- No numpy, pandas, tensorflow, opencv
- Handle all errors gracefully
- Return helpful values

Generate ONLY the Python code, no explanations."""

        messages = [{"role": "user", "content": prompt}]
        code = self.assistant.ai_engine.chat_sync(messages)
        
        if not code:
            return (False, "Failed to generate feature code")
        
        # Extract code from markdown if present
        if "```python" in code:
            code = code.split("```python")[1].split("```")[0].strip()
        elif "```" in code:
            code = code.split("```")[1].split("```")[0].strip()
        
        # Test code syntax
        try:
            ast.parse(code)
        except SyntaxError:
            return (False, "Generated code has syntax errors")
        
        # Save and load plugin
        try:
            plugin_name = "custom_" + str(int(time.time()))
            plugin_file = self.assistant.plugins_dir / f"{plugin_name}.py"
            plugin_file.write_text(code)
            self.assistant.plugin_manager._load_plugins()
            
            if plugin_name in self.assistant.plugin_manager.plugins:
                return (True, f"✅ Custom feature '{description}' successfully added!")
            else:
                return (False, "Plugin created but failed to load")
        except Exception as e:
            return (False, f"Error: {str(e)}")
    
    def create_project_automatically(self, project_name: str, description: str, project_type: str = "python") -> Tuple[bool, str]:
        """
        Actually create a complete working project
        """
        print(f"\n📦 Creating project: {project_name}")
        print("⏳ Generating files...")
        
        project_dir = self.assistant.projects_dir / project_name
        project_dir.mkdir(parents=True, exist_ok=True)
        
        if project_type == "python":
            return self._create_python_project(project_dir, project_name, description)
        elif project_type == "calculator":
            return self._create_calculator_project(project_dir, project_name)
        elif project_type == "automation":
            return self._create_automation_project(project_dir, project_name)
        else:
            return self._create_generic_project(project_dir, project_name, description)
    
    def _create_python_project(self, project_dir: Path, name: str, description: str) -> Tuple[bool, str]:
        """Create a complete Python project"""
        try:
            # Create structure
            (project_dir / "src").mkdir(exist_ok=True)
            (project_dir / "tests").mkdir(exist_ok=True)
            
            # Main file
            main_code = f'''#!/usr/bin/env python3
"""
{name} - {description}
"""

def main():
    print("Hello from {name}!")
    print("{description}")

if __name__ == "__main__":
    main()
'''
            (project_dir / "src" / "main.py").write_text(main_code)
            
            # README
            readme = f'''# {name}

{description}

## Installation
```bash
cd {project_dir}
python src/main.py
```

## Features
- Pure Python
- Termux compatible
- Easy to use
'''
            (project_dir / "README.md").write_text(readme)
            
            # requirements.txt
            (project_dir / "requirements.txt").write_text("# Add dependencies here\n")
            
            # Make executable
            main_file = project_dir / "src" / "main.py"
            os.chmod(main_file, 0o755)
            
            return (True, f"✅ Project '{name}' created successfully at {project_dir}\nRun: python {main_file}")
        
        except Exception as e:
            return (False, f"Error creating project: {str(e)}")
    
    def _create_calculator_project(self, project_dir: Path, name: str) -> Tuple[bool, str]:
        """Create calculator project"""
        calculator_code = '''#!/usr/bin/env python3
"""
Advanced Calculator - Termux Compatible
"""

import math

def calculate(expression):
    """Safely evaluate expression"""
    try:
        safe_dict = {
            "abs": abs, "round": round, "min": min, "max": max,
            "sum": sum, "pow": pow, "sqrt": math.sqrt,
            "sin": math.sin, "cos": math.cos, "tan": math.tan,
            "log": math.log, "exp": math.exp,
            "pi": math.pi, "e": math.e
        }
        result = eval(expression, {"__builtins__": {}}, safe_dict)
        return result
    except Exception as e:
        return f"Error: {e}"

def main():
    print("=" * 50)
    print("Advanced Calculator")
    print("=" * 50)
    print("Operations: +, -, *, /, **, sqrt(), sin(), cos()")
    print("Constants: pi, e")
    print("Type 'exit' to quit")
    print("=" * 50)
    
    while True:
        try:
            expr = input("\\nCalculate: ").strip()
            if expr.lower() in ['exit', 'quit']:
                break
            result = calculate(expr)
            print(f"Result: {result}")
        except KeyboardInterrupt:
            break

if __name__ == "__main__":
    main()
'''
        
        try:
            main_file = project_dir / "calculator.py"
            main_file.write_text(calculator_code)
            os.chmod(main_file, 0o755)
            
            readme = f'''# Calculator Project

Advanced calculator with math functions.

## Usage
```bash
python {main_file}
```

## Features
- Basic operations: +, -, *, /, **
- Math functions: sqrt, sin, cos, tan, log, exp
- Constants: pi, e
'''
            (project_dir / "README.md").write_text(readme)
            
            return (True, f"✅ Calculator project created!\nRun: python {main_file}")
        except Exception as e:
            return (False, f"Error: {str(e)}")
    
    def _create_automation_project(self, project_dir: Path, name: str) -> Tuple[bool, str]:
        """Create automation project"""
        automation_code = '''#!/usr/bin/env python3
"""
Termux Automation Script
"""

import subprocess
import os
from datetime import datetime

class TermuxAutomation:
    def __init__(self):
        self.commands = {}
    
    def add_command(self, name, command):
        """Add a command"""
        self.commands[name] = command
    
    def run_command(self, name):
        """Run a saved command"""
        if name in self.commands:
            try:
                result = subprocess.run(
                    self.commands[name],
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=30
                )
                return result.stdout
            except Exception as e:
                return f"Error: {e}"
        return "Command not found"
    
    def list_commands(self):
        """List all commands"""
        return list(self.commands.keys())

def main():
    auto = TermuxAutomation()
    
    # Example commands
    auto.add_command("list_files", "ls -la")
    auto.add_command("disk_space", "df -h")
    auto.add_command("memory", "free -h")
    
    print("Termux Automation")
    print("Available commands:", auto.list_commands())
    
    while True:
        cmd = input("\\nCommand (or 'exit'): ").strip()
        if cmd == 'exit':
            break
        result = auto.run_command(cmd)
        print(result)

if __name__ == "__main__":
    main()
'''
        
        try:
            main_file = project_dir / "automation.py"
            main_file.write_text(automation_code)
            os.chmod(main_file, 0o755)
            
            readme = '''# Termux Automation Project

Automate Termux commands.

## Usage
```bash
python automation.py
```

## Features
- Save frequently used commands
- Execute with one word
- Expandable
'''
            (project_dir / "README.md").write_text(readme)
            
            return (True, f"✅ Automation project created!\nRun: python {main_file}")
        except Exception as e:
            return (False, f"Error: {str(e)}")
    
    def _create_generic_project(self, project_dir: Path, name: str, description: str) -> Tuple[bool, str]:
        """Create generic project"""
        return self._create_python_project(project_dir, name, description)
    
    def fix_errors_automatically(self, project_path: Path) -> Tuple[bool, str]:
        """
        Actually fix errors in a project
        """
        print(f"\n🔧 Analyzing {project_path}...")
        
        errors_found = []
        fixes_applied = []
        
        # Analyze all Python files
        for py_file in project_path.rglob("*.py"):
            try:
                content = py_file.read_text()
                ast.parse(content)
            except SyntaxError as e:
                errors_found.append((py_file, str(e)))
        
        if not errors_found:
            return (True, "✅ No errors found!")
        
        print(f"❌ Found {len(errors_found)} errors")
        print("🔧 Attempting to fix...")
        
        # Try to fix each error
        for file_path, error in errors_found:
            fixed = self._try_fix_syntax_error(file_path, error)
            if fixed:
                fixes_applied.append(file_path.name)
        
        if len(fixes_applied) == len(errors_found):
            return (True, f"✅ All {len(fixes_applied)} errors fixed!")
        else:
            return (False, f"⚠️ Fixed {len(fixes_applied)}/{len(errors_found)} errors")
    
    def _try_fix_syntax_error(self, file_path: Path, error: str) -> bool:
        """Try to fix a syntax error"""
        try:
            content = file_path.read_text()
            
            # Common fixes
            fixes = [
                (r'print ([^(].*)', r'print(\1)'),  # print statement to print()
                (r'(\s+)([a-zA-Z_]\w*)\s*=\s*raw_input', r'\1\2 = input'),  # raw_input to input
                (r'xrange\(', r'range('),  # xrange to range
            ]
            
            for pattern, replacement in fixes:
                content = re.sub(pattern, replacement, content)
            
            # Test if fixed
            ast.parse(content)
            
            # Save fixed version
            file_path.write_text(content)
            return True
        
        except:
            return False
    
    def execute_termux_command(self, command: str) -> Tuple[bool, str]:
        """Execute a Termux command and return result"""
        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            output = result.stdout if result.stdout else result.stderr
            return (result.returncode == 0, output)
        
        except subprocess.TimeoutExpired:
            return (False, "Command timed out")
        except Exception as e:
            return (False, f"Error: {str(e)}")
