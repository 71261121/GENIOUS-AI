# Advanced Self-Improving AI Assistant

🚀 **100% Termux Compatible | Zero Dependency Errors | Conversational Interface**

## Key Features

- ✅ **Conversational Chat Interface** - No menus, natural conversation
- ✅ **Self-Modifying Plugin System** - Add features at runtime
- ✅ **Auto Error Recovery** - 5+ fallback strategies, never shows errors
- ✅ **OpenRouter Integration** - Multiple free models with auto-switching
- ✅ **Project Management** - Create, analyze, fix, and run Python projects
- ✅ **GitHub Learning** - Learn from code examples
- ✅ **Memory System** - Remembers conversations and learns preferences
- ✅ **Pre-execution Testing** - Tests modifications before applying
- ✅ **100% Pure Python** - No numpy, pandas, tensorflow, opencv
- ✅ **Lightweight** - ~5-10MB vs 500MB+ in other assistants

## Installation (Termux)

```bash
# Update Termux
pkg update && pkg upgrade

# Install Python
pkg install python python-pip git

# Clone or copy this project
cd ~/
python jarvis_advanced.py

# It will prompt for OpenRouter API key on first run
```

## Getting OpenRouter API Key (FREE)

1. Visit: https://openrouter.ai/
2. Sign up (free)
3. Go to Keys section
4. Create new key
5. Copy and paste when the assistant asks

## Free Models Included

- DeepSeek Chat (best for coding)
- Mistral 7B Instruct
- Llama 3.2 3B (free tier)
- Gemma 2 9B (free tier)
- Phi-3 Mini (free tier)

## Usage Examples

### Start the Assistant
```bash
python jarvis_advanced.py
```

### Conversation Examples

**Create a project:**
```
You: Mujhe ek calculator app banana hai
AI: [Creates project automatically]
```

**Analyze a project:**
```
You: Mere project mein errors check karo
AI: [Analyzes and reports errors]
```

**Fix errors:**
```
You: Is project ko fix kar do
AI: [Automatically fixes errors]
```

**Add voice feature:**
```
You: Apne mein voice feature add karo
AI: [Modifies itself to add voice capability]
```

**Learn from GitHub:**
```
You: GitHub se seekh kar khud ko improve karo
AI: [Learns from GitHub repos]
```

## Architecture

```
.ai_assistant/
├── data/           # Configuration
├── plugins/        # Runtime-loaded plugins
├── memory/         # Conversation and learning memory
├── projects/       # User projects
└── logs/          # Activity logs
```

## What Makes This Different?

### ❌ Old Assistant Problems:
- 500MB+ dependencies
- numpy, pandas, tensorflow (don't work on Termux)
- Menu-based interface
- Shows errors to users
- Complex and slow

### ✅ This Assistant:
- 5-10MB total size
- 100% pure Python
- Conversational chat
- Auto-fixes all errors
- Fast and lightweight

## Termux Compatibility

All dependencies are **pure Python** and work perfectly on Termux:
- ✅ requests (HTTP client)
- ✅ aiohttp (async HTTP)
- ✅ aiofiles (async file I/O)
- ✅ rich (terminal UI)
- ✅ gitpython (Git operations)
- ✅ python-dotenv (environment variables)

**NO problematic libraries:**
- ❌ numpy, pandas, scipy
- ❌ tensorflow, pytorch, transformers
- ❌ opencv-python
- ❌ matplotlib, seaborn

## Self-Modification Example

```python
# User says: "Add a calculator plugin"
# AI generates and tests this code:

class CalculatorPlugin:
    is_plugin = True
    
    def __init__(self, assistant):
        self.assistant = assistant
    
    def execute(self, operation, a, b):
        if operation == 'add':
            return a + b
        elif operation == 'subtract':
            return a - b
        # etc.

# AI tests it in sandbox, then adds it to plugins/
# Now calculator is available!
```

## Error Recovery Example

```python
# When an error occurs:
# Strategy 1: Retry with delay (3 attempts)
# Strategy 2: Try alternative approach
# Strategy 3: Use simplified version  
# Strategy 4: Manual fallback
# Strategy 5: Graceful degradation

# User NEVER sees the error!
```

## Configuration

Edit `~/.ai_assistant/data/config.json`:

```json
{
  "openrouter_api_key": "your-key-here",
  "free_models": [
    "deepseek/deepseek-chat",
    "mistralai/mistral-7b-instruct",
    "meta-llama/llama-3.2-3b-instruct:free"
  ],
  "auto_improve": true,
  "auto_fix_errors": true,
  "github_learning": true,
  "max_retry_attempts": 5
}
```

## Future Enhancements

- [ ] Voice input/output using Termux-API
- [ ] Advanced code analysis
- [ ] More GitHub learning strategies
- [ ] Plugin marketplace
- [ ] Multi-assistant collaboration
- [ ] Advanced project templates

## Troubleshooting

**Problem:** "ModuleNotFoundError: No module named 'aiohttp'"
**Solution:** `pip install -r requirements.txt`

**Problem:** "API key not working"
**Solution:** Verify key at openrouter.ai/keys

**Problem:** "Slow responses"
**Solution:** Check internet connection, AI may switch to faster model

## License

MIT License - Free to use and modify

## Author

Advanced AI Assistant Team
Version 1.0.0
